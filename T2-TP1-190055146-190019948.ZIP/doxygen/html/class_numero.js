var class_numero =
[
    [ "Numero", "class_numero.html#a23be6111c6f012a235c26490c7fa0e73", null ],
    [ "getValor", "class_numero.html#ac2a8804abadc29da9bd01511a0fb6432", null ],
    [ "setValor", "class_numero.html#a4775bf674ae38dc3407a334ed220e6b3", null ],
    [ "validate", "class_numero.html#a3d215c2e4d293c147cd82dcdfd4ab48b", null ],
    [ "tamanho", "class_numero.html#a9b8dcc5b11c8b4a5c4e5e49813055f97", null ],
    [ "valor", "class_numero.html#ad4bb5429583c1591b593f3fff3e2e35c", null ]
];