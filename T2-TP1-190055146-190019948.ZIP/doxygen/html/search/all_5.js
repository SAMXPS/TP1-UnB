var searchData=
[
  ['falhou_56',['FALHOU',['../class_resultado_t_u.html#a7613ec92c1b47a4cd9979758f608d96c',1,'ResultadoTU']]],
  ['falhoupassou_57',['falhouPassou',['../class_resultado_t_u.html#a26bc6f5568b3d59d12afd01214e65d01',1,'ResultadoTU']]]
];
