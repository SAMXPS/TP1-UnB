var indexSectionsWithContent =
{
  0: "abcdefghimnprstuv",
  1: "acdehnprstuv",
  2: "acdehmnprstuv",
  3: "acdefghmnpstuv",
  4: "abcdefhimnpstv"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "Tudo",
  1: "Classes",
  2: "Ficheiros",
  3: "Funções",
  4: "Variáveis"
};

