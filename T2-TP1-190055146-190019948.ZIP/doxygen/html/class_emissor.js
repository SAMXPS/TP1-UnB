var class_emissor =
[
    [ "Emissor", "class_emissor.html#a4f17d6a9c70fcf6b39c57e4f6fca98bc", null ],
    [ "getValor", "class_emissor.html#a646181613aaac681b3588f61b6dc6dbc", null ],
    [ "setValor", "class_emissor.html#a034d75d0f56e1d00e7d7d911b317b255", null ],
    [ "validate", "class_emissor.html#a12a5e42768c286da5f54897e63f41c06", null ],
    [ "maximo", "class_emissor.html#a27c552ca06622a1af18bd3fa16c10fe1", null ],
    [ "minimo", "class_emissor.html#aa830aefefab5911e4a63ba569f2b5469", null ],
    [ "valor", "class_emissor.html#ace7dc845e0f80a6e3d138d8697d9e98c", null ]
];