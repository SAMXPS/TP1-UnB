var main_8cpp =
[
    [ "main", "main_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4", null ],
    [ "VERBOSE", "main_8cpp.html#ade3d6e6e4c0211df42ec4b9e76671bfb", null ]
];