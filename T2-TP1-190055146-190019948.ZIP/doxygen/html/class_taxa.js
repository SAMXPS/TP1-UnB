var class_taxa =
[
    [ "Taxa", "class_taxa.html#a3bc8b02b84d4781e0396c840dbb44c2e", null ],
    [ "getValor", "class_taxa.html#a6c5742e5d5dc4e3f4e964c41063b9590", null ],
    [ "setValor", "class_taxa.html#a6c0d277ce4aa92f344f68f642e77fbfb", null ],
    [ "validate", "class_taxa.html#a6ec74a362cf71d635b9cdd6fec05b900", null ],
    [ "valor", "class_taxa.html#aa665b8190d709f84dd36a98446bcb8f7", null ]
];