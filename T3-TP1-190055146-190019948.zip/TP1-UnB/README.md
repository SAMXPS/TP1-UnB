## Como começar

- Acessar [página de downloads](http://www.codeblocks.org/downloads/binaries) do codeblocks
- Instalar IDE Code::Blocks [codeblocks-20.03mingw-setup.exe](http://sourceforge.net/projects/codeblocks/files/Binaries/20.03/Windows/codeblocks-20.03mingw-setup.exe)
- Caso tenha algum problema com compilador, instalar o [MinGW](https://osdn.net/frs/redir.php?m=constant&f=mingw%2F68260%2Fmingw-get-setup.exe) e marcar *mingw32-gcc-g++* para instalação.


Instalar também:
libpdcurses-3.4-1-mingw32-dll.tar.lzma
PDCurses-3.4-1-mingw32-bin.tar.lzma
libpdcurses-3.4-1-mingw32-dev.tar.lzma
