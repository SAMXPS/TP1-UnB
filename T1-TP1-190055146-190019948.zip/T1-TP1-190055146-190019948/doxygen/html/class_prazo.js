var class_prazo =
[
    [ "Prazo", "class_prazo.html#a89ce3ecc1c02f2984ed1e5bb0356d7d5", null ],
    [ "getValor", "class_prazo.html#a9949e01d9337f676ff71a0afd0cd1577", null ],
    [ "setValor", "class_prazo.html#a6bbd23bb220141aeffcb13fbbc4a0f31", null ]
];