var class_nome =
[
    [ "Nome", "class_nome.html#adb92e0149b012b89be5a41239a97e1a3", null ],
    [ "getValor", "class_nome.html#a1e402450a136c9bbfcf9e198651f34f2", null ],
    [ "setValor", "class_nome.html#af371fc1ddf8ea83feb0bee1480f6881f", null ]
];