var class_numero =
[
    [ "Numero", "class_numero.html#a23be6111c6f012a235c26490c7fa0e73", null ],
    [ "getValor", "class_numero.html#ac2a8804abadc29da9bd01511a0fb6432", null ],
    [ "setValor", "class_numero.html#a4775bf674ae38dc3407a334ed220e6b3", null ]
];