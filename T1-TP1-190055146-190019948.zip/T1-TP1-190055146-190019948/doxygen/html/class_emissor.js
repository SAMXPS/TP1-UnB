var class_emissor =
[
    [ "Emissor", "class_emissor.html#a4f17d6a9c70fcf6b39c57e4f6fca98bc", null ],
    [ "getValor", "class_emissor.html#a646181613aaac681b3588f61b6dc6dbc", null ],
    [ "setValor", "class_emissor.html#a034d75d0f56e1d00e7d7d911b317b255", null ]
];