var searchData=
[
  ['data_7',['Data',['../class_data.html',1,'Data'],['../class_data.html#a4e00eb58c9a0fe9f1803f02cba83c7b7',1,'Data::Data()']]]
];
