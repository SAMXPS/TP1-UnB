var searchData=
[
  ['taxa_93',['Taxa',['../class_taxa.html#a3bc8b02b84d4781e0396c840dbb44c2e',1,'Taxa']]]
];
