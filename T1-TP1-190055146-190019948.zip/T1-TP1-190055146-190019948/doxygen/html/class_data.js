var class_data =
[
    [ "Data", "class_data.html#a4e00eb58c9a0fe9f1803f02cba83c7b7", null ],
    [ "getValor", "class_data.html#a9a06590c5bbe482b9a49bbd6f5210f52", null ],
    [ "setValor", "class_data.html#a530cdbf504de91c6588daed58a20fd2d", null ]
];