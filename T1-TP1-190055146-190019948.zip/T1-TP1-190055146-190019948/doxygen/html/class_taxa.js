var class_taxa =
[
    [ "Taxa", "class_taxa.html#a3bc8b02b84d4781e0396c840dbb44c2e", null ],
    [ "getValor", "class_taxa.html#a6c5742e5d5dc4e3f4e964c41063b9590", null ],
    [ "setValor", "class_taxa.html#a6c0d277ce4aa92f344f68f642e77fbfb", null ]
];